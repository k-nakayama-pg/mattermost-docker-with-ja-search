-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION testsearch_ja UPDATE TO '9.6'" to load this file. \quit

-- noop
