SET client_min_messages = warning;
\set ECHO all
CREATE EXTENSION textsearch_ja;
\dx textsearch_ja
\dx+ textsearch_ja
RESET client_min_messages;
