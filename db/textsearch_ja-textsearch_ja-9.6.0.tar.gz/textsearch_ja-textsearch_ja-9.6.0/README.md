textsearch_ja
====

形態素解析を使用した日本語全文検索の、PostgreSQL組み込み型モジュール。
非公式にPostgreSQL 9.1以降に対応させています。

## 参照

* 公式
 - http://textsearch-ja.projects.pgfoundry.org/textsearch_ja.html
 - 使い方などは、公式サイトを参照してください。
